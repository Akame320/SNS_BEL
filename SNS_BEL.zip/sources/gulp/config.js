module.exports = [
    "./gulp/tasks/pug",
    "./gulp/tasks/styles",
    "./gulp/tasks/scripts",
    "./gulp/tasks/favicons",
    "./gulp/tasks/images",
    "./gulp/tasks/sprite",
    "./gulp/tasks/fonts",
    "./gulp/tasks/libs",
    "./gulp/tasks/watch",
    "./gulp/tasks/clean",
    "./gulp/tasks/serve"
];