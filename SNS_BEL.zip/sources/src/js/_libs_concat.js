module.exports = [
    "./src/libs/jquery/dist/jquery.min.js",
    "./src/libs/jquery.maskedinput.js",
    "./src/libs/valid/form.js"
    // "./src/libs/simplebar/dist/simplebar.min.js",
];
